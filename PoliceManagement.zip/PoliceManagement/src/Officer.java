public class Officer {
    private int officerID;
    private String firstName;
    private String lastName;
    private String rank;
    private String phone;

    public Officer(int officerID, String firstName, String lastName, String rank, String phone) {
        this.officerID = officerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.rank = rank;
        this.phone = phone;
    }

    public Officer(String firstName, String lastName, String rank, String phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.rank = rank;
        this.phone = phone;
    }

    public int getOfficerID() { return officerID; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getRank() { return rank; }
    public String getPhone() { return phone; }
}
