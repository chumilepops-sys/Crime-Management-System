import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OfficerDAO {

    public void addOfficer(Officer officer) throws SQLException {
        String sql = "INSERT INTO officer (FirstName, LastName, `Rank`, Phone) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, officer.getFirstName());
            stmt.setString(2, officer.getLastName());
            stmt.setString(3, officer.getRank());
            stmt.setString(4, officer.getPhone());
            stmt.executeUpdate();
        }
    }

    public void updateOfficer(Officer officer) throws SQLException {
        String sql = "UPDATE officer SET FirstName=?, LastName=?, `Rank`=?, Phone=? WHERE OfficerID=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, officer.getFirstName());
            stmt.setString(2, officer.getLastName());
            stmt.setString(3, officer.getRank());
            stmt.setString(4, officer.getPhone());
            stmt.setInt(5, officer.getOfficerID());
            stmt.executeUpdate();
        }
    }

    public void deleteOfficer(int officerID) throws SQLException {
        String sql = "DELETE FROM officer WHERE OfficerID=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, officerID);
            stmt.executeUpdate();
        }
    }

    public List<Officer> getAllOfficers() throws SQLException {
        List<Officer> list = new ArrayList<>();
        String sql = "SELECT * FROM officer";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Officer(
                        rs.getInt("OfficerID"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("Rank"),
                        rs.getString("Phone")
                ));
            }
        }
        return list;
    }
}
