import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class PoliceManagementGUI extends JFrame {

    private JTextField txtOfficerID, txtFirstName, txtLastName, txtRank, txtPhone;
    private JTable tblOfficers;
    private JButton btnAddOfficer, btnUpdateOfficer, btnDeleteOfficer, btnRefreshOfficer;

    private JTextField txtCaseID, txtCaseDetails, txtAttendingOfficer, txtCategory, txtLocation, txtReportedOn, txtStatus;
    private JTable tblCases;
    private JButton btnAddCase, btnUpdateCase, btnDeleteCase, btnRefreshCase;

    public PoliceManagementGUI() {
        setTitle("Police Case Management System");
        setSize(1000, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel officerPanel = new JPanel(new BorderLayout());
        officerPanel.add(createOfficerInputPanel(), BorderLayout.NORTH);
        officerPanel.add(createOfficerTablePanel(), BorderLayout.CENTER);
        tabbedPane.add("Officers", officerPanel);

        JPanel casePanel = new JPanel(new BorderLayout());
        casePanel.add(createCaseInputPanel(), BorderLayout.NORTH);
        casePanel.add(createCaseTablePanel(), BorderLayout.CENTER);
        tabbedPane.add("Cases", casePanel);

        add(tabbedPane, BorderLayout.CENTER);
        refreshOfficerTable();
        refreshCaseTable();
        setVisible(true);
    }

    private JPanel createOfficerInputPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 6, 5, 5));

        panel.add(new JLabel("Officer ID"));
        panel.add(new JLabel("First Name"));
        panel.add(new JLabel("Last Name"));
        panel.add(new JLabel("Rank"));
        panel.add(new JLabel("Phone"));
        panel.add(new JLabel("Actions"));

        txtOfficerID = new JTextField();
        txtFirstName = new JTextField();
        txtLastName = new JTextField();
        txtRank = new JTextField();
        txtPhone = new JTextField();

        panel.add(txtOfficerID);
        panel.add(txtFirstName);
        panel.add(txtLastName);
        panel.add(txtRank);
        panel.add(txtPhone);

        JPanel buttonPanel = new JPanel();
        btnAddOfficer = new JButton("Add");
        btnUpdateOfficer = new JButton("Update");
        btnDeleteOfficer = new JButton("Delete");
        btnRefreshOfficer = new JButton("Refresh");

        buttonPanel.add(btnAddOfficer);
        buttonPanel.add(btnUpdateOfficer);
        buttonPanel.add(btnDeleteOfficer);
        buttonPanel.add(btnRefreshOfficer);
        panel.add(buttonPanel);

        btnAddOfficer.addActionListener(e -> addOfficer());
        btnUpdateOfficer.addActionListener(e -> updateOfficer());
        btnDeleteOfficer.addActionListener(e -> deleteOfficer());
        btnRefreshOfficer.addActionListener(e -> refreshOfficerTable());

        return panel;
    }

    private JScrollPane createOfficerTablePanel() {
        tblOfficers = new JTable();
        tblOfficers.setModel(new DefaultTableModel(new Object[]{"ID","First Name","Last Name","Rank","Phone"},0));
        tblOfficers.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = tblOfficers.getSelectedRow();
                if(selectedRow != -1) {
                    txtOfficerID.setText(tblOfficers.getValueAt(selectedRow, 0).toString());
                    txtFirstName.setText(tblOfficers.getValueAt(selectedRow, 1).toString());
                    txtLastName.setText(tblOfficers.getValueAt(selectedRow, 2).toString());
                    txtRank.setText(tblOfficers.getValueAt(selectedRow, 3).toString());
                    txtPhone.setText(tblOfficers.getValueAt(selectedRow, 4).toString());
                }
            }
        });
        return new JScrollPane(tblOfficers);
    }

    private JPanel createCaseInputPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 7, 5, 5));

        panel.add(new JLabel("Case ID"));
        panel.add(new JLabel("Details"));
        panel.add(new JLabel("Officer"));
        panel.add(new JLabel("Category"));
        panel.add(new JLabel("Location"));
        panel.add(new JLabel("Reported On"));
        panel.add(new JLabel("Status"));

        txtCaseID = new JTextField();
        txtCaseDetails = new JTextField();
        txtAttendingOfficer = new JTextField();
        txtCategory = new JTextField();
        txtLocation = new JTextField();
        txtReportedOn = new JTextField();
        txtStatus = new JTextField();

        panel.add(txtCaseID);
        panel.add(txtCaseDetails);
        panel.add(txtAttendingOfficer);
        panel.add(txtCategory);
        panel.add(txtLocation);
        panel.add(txtReportedOn);
        panel.add(txtStatus);

        JPanel buttonPanel = new JPanel();
        btnAddCase = new JButton("Add");
        btnUpdateCase = new JButton("Update");
        btnDeleteCase = new JButton("Delete");
        btnRefreshCase = new JButton("Refresh");

        buttonPanel.add(btnAddCase);
        buttonPanel.add(btnUpdateCase);
        buttonPanel.add(btnDeleteCase);
        buttonPanel.add(btnRefreshCase);
        panel.add(buttonPanel);

        btnAddCase.addActionListener(e -> addCase());
        btnUpdateCase.addActionListener(e -> updateCase());
        btnDeleteCase.addActionListener(e -> deleteCase());
        btnRefreshCase.addActionListener(e -> refreshCaseTable());

        return panel;
    }

    private JScrollPane createCaseTablePanel() {
        tblCases = new JTable();
        tblCases.setModel(new DefaultTableModel(new Object[]{"ID","Details","Officer","Category","Location","ReportedOn","Status"},0));
        tblCases.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = tblCases.getSelectedRow();
                if(selectedRow != -1) {
                    txtCaseID.setText(tblCases.getValueAt(selectedRow, 0).toString());
                    txtCaseDetails.setText(tblCases.getValueAt(selectedRow, 1).toString());
                    txtAttendingOfficer.setText(tblCases.getValueAt(selectedRow, 2).toString());
                    txtCategory.setText(tblCases.getValueAt(selectedRow, 3).toString());
                    txtLocation.setText(tblCases.getValueAt(selectedRow, 4).toString());
                    txtReportedOn.setText(tblCases.getValueAt(selectedRow, 5).toString());
                    txtStatus.setText(tblCases.getValueAt(selectedRow, 6).toString());
                }
            }
        });
        return new JScrollPane(tblCases);
    }

    // Officer Methods
    private void addOfficer() {
        try {
            Officer o = new Officer(txtFirstName.getText(), txtLastName.getText(), txtRank.getText(), txtPhone.getText());
            OfficerDAO dao = new OfficerDAO();
            dao.addOfficer(o);
            refreshOfficerTable();
            JOptionPane.showMessageDialog(this, "Officer added!");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, "Error: "+e.getMessage());
        }
    }

    private void updateOfficer() {
        try {
            Officer o = new Officer(Integer.parseInt(txtOfficerID.getText()), txtFirstName.getText(), txtLastName.getText(), txtRank.getText(), txtPhone.getText());
            OfficerDAO dao = new OfficerDAO();
            dao.updateOfficer(o);
            refreshOfficerTable();
            JOptionPane.showMessageDialog(this, "Officer updated!");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, "Error: "+e.getMessage());
        }
    }

    private void deleteOfficer() {
        try {
            int id = Integer.parseInt(txtOfficerID.getText());
            OfficerDAO dao = new OfficerDAO();
            dao.deleteOfficer(id);
            refreshOfficerTable();
            JOptionPane.showMessageDialog(this, "Officer deleted!");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, "Error: "+e.getMessage());
        }
    }

    private void refreshOfficerTable() {
        try {
            OfficerDAO dao = new OfficerDAO();
            List<Officer> list = dao.getAllOfficers();
            DefaultTableModel model = (DefaultTableModel) tblOfficers.getModel();
            model.setRowCount(0);
            for(Officer o : list) {
                model.addRow(new Object[]{o.getOfficerID(), o.getFirstName(), o.getLastName(), o.getRank(), o.getPhone()});
            }
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading officers: "+e.getMessage());
        }
    }

    // Case Methods
    private void addCase() {
        try {
            CaseFile c = new CaseFile(txtCaseDetails.getText(), txtAttendingOfficer.getText(), txtCategory.getText(), txtLocation.getText(), java.sql.Date.valueOf(txtReportedOn.getText()), txtStatus.getText());
            CaseFileDAO dao = new CaseFileDAO();
            dao.addCase(c);
            refreshCaseTable();
            JOptionPane.showMessageDialog(this, "Case added!");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, "Error: "+e.getMessage());
        }
    }

    private void updateCase() {
        try {
            CaseFile c = new CaseFile(Integer.parseInt(txtCaseID.getText()), txtCaseDetails.getText(), txtAttendingOfficer.getText(), txtCategory.getText(), txtLocation.getText(), java.sql.Date.valueOf(txtReportedOn.getText()), txtStatus.getText());
            CaseFileDAO dao = new CaseFileDAO();
            dao.updateCase(c);
            refreshCaseTable();
            JOptionPane.showMessageDialog(this, "Case updated!");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, "Error: "+e.getMessage());
        }
    }

    private void deleteCase() {
        try {
            int id = Integer.parseInt(txtCaseID.getText());
            CaseFileDAO dao = new CaseFileDAO();
            dao.deleteCase(id);
            refreshCaseTable();
            JOptionPane.showMessageDialog(this, "Case deleted!");
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, "Error: "+e.getMessage());
        }
    }

    private void refreshCaseTable() {
        try {
            CaseFileDAO dao = new CaseFileDAO();
            List<CaseFile> list = dao.getAllCases();
            DefaultTableModel model = (DefaultTableModel) tblCases.getModel();
            model.setRowCount(0);
            for(CaseFile c : list) {
                model.addRow(new Object[]{c.getCaseID(), c.getCaseDetails(), c.getAttendingOfficer(), c.getCategory(), c.getLocation(), c.getReportedOn(), c.getStatus()});
            }
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading cases: "+e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PoliceManagementGUI::new);
    }
}
