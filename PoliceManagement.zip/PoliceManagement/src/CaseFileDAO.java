import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CaseFileDAO {

    public void addCase(CaseFile c) throws SQLException {
        String sql = "INSERT INTO cases (CaseDetails, AttendingOfficer, Category, Location, ReportedOn, Status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, c.getCaseDetails());
            stmt.setString(2, c.getAttendingOfficer());
            stmt.setString(3, c.getCategory());
            stmt.setString(4, c.getLocation());
            stmt.setDate(5, c.getReportedOn());
            stmt.setString(6, c.getStatus());
            stmt.executeUpdate();
        }
    }

    public void updateCase(CaseFile c) throws SQLException {
        String sql = "UPDATE cases SET CaseDetails=?, AttendingOfficer=?, Category=?, Location=?, ReportedOn=?, Status=? WHERE CaseID=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, c.getCaseDetails());
            stmt.setString(2, c.getAttendingOfficer());
            stmt.setString(3, c.getCategory());
            stmt.setString(4, c.getLocation());
            stmt.setDate(5, c.getReportedOn());
            stmt.setString(6, c.getStatus());
            stmt.setInt(7, c.getCaseID());
            stmt.executeUpdate();
        }
    }

    public void deleteCase(int caseID) throws SQLException {
        String sql = "DELETE FROM cases WHERE CaseID=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, caseID);
            stmt.executeUpdate();
        }
    }

    public List<CaseFile> getAllCases() throws SQLException {
        List<CaseFile> list = new ArrayList<>();
        String sql = "SELECT * FROM cases";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new CaseFile(
                        rs.getInt("CaseID"),
                        rs.getString("CaseDetails"),
                        rs.getString("AttendingOfficer"),
                        rs.getString("Category"),
                        rs.getString("Location"),
                        rs.getDate("ReportedOn"),
                        rs.getString("Status")
                ));
            }
        }
        return list;
    }
}
