import java.sql.Date;

public class CaseFile {
    private int caseID;
    private String caseDetails;
    private String attendingOfficer;
    private String category;
    private String location;
    private Date reportedOn;
    private String status;

    public CaseFile(int caseID, String caseDetails, String attendingOfficer, String category, String location, Date reportedOn, String status) {
        this.caseID = caseID;
        this.caseDetails = caseDetails;
        this.attendingOfficer = attendingOfficer;
        this.category = category;
        this.location = location;
        this.reportedOn = reportedOn;
        this.status = status;
    }

    public CaseFile(String caseDetails, String attendingOfficer, String category, String location, Date reportedOn, String status) {
        this.caseDetails = caseDetails;
        this.attendingOfficer = attendingOfficer;
        this.category = category;
        this.location = location;
        this.reportedOn = reportedOn;
        this.status = status;
    }

    public int getCaseID() { return caseID; }
    public String getCaseDetails() { return caseDetails; }
    public String getAttendingOfficer() { return attendingOfficer; }
    public String getCategory() { return category; }
    public String getLocation() { return location; }
    public Date getReportedOn() { return reportedOn; }
    public String getStatus() { return status; }
}
